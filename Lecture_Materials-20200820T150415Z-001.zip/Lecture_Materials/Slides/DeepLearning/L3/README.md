These slides are available on https://indianinstituteofscience-my.sharepoint.com/:p:/g/personal/arjunjain_iisc_ac_in/EV-11sdJcyRNl2ta7vP6NpcB6Nk0vmxEGqjYygIEKKnJPQ?e=f0LAXz 
