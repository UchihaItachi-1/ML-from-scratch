Please download the required dataset from the link given below: 

[uci-news-aggregator.csv](https://drive.google.com/file/d/1TllpnNK46p0OAWb5VPgGGi8R5EaScjb-/view?usp=sharing)

