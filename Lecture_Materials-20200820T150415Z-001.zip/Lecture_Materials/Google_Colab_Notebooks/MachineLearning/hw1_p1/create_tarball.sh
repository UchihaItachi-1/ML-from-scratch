tar -cvf handin.tar hw1 mytorch
